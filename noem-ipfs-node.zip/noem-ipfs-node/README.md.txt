

NOEM IPFS Node
Welcome to the NOEM IPFS Node! This guide will help you set up and run your IPFS node to participate in the NOEM network and earn rewards by sharing your storage.

Installation
Before you begin, ensure you have Node.js installed on your system. You can download it from https://nodejs.org/.

Follow these steps to install your NOEM IPFS Node:

Unzip the package:

unzip noem-ipfs-node.zip

Navigate to the project directory:

cd ./noem-ipfs-node

Configure your wallet and storage:
Before running the installation script, you must edit the config.json file.

Input your Bahamut EVM compatible wallet address. All rewards will be distributed to this address.

Specify the amount of storage you want to share.

Important Note: The wallet address configured in config.json will be used for all reward distributions. For now, this address cannot be changed after initial setup. Please ensure you use a wallet address that you will not lose or replace. Reward distribution will be based on your provided storage and the strike day node login activity.

Run the installation script:

bash install.sh

During the installation, you will be prompted to enter your Bahamut-supported EVM wallet address and the amount of storage you wish to provide. Make sure these match your config.json settings.

Running the Node
Once the installation is complete, you can start your node's heartbeat service:

node heartbeat.js

You should see output similar to this, confirming your heartbeat is being sent:

Sent heartbeat for 0x.......

Troubleshooting
If you encounter issues during or after installation, refer to these common solutions.

Axios Not Found Error
If you get an error indicating axios is not found, try installing it manually:

npm install axios

You should see confirmation that the package was added:

added 1 package, and audited 2 packages in 1s

Then, try running the heartbeat again:

node heartbeat.js

Switching to IPv4 (Persistent Errors)
If you continue to face installation issues, particularly network-related ones, you might need to force npm to prefer IPv4. Run these commands once in your terminal, then try npm install axios again:

npm config set prefer-online true
npm config set registry https://registry.npmjs.org/
npm config set fetch-retries 5
npm config set fetch-retry-mintimeout 20000
npm config set fetch-retry-maxtimeout 120000

After setting the npm configurations, force IPv4 and attempt to install axios:

NODE_OPTIONS="--dns-result-order=ipv4first" npm install axios

Once axios installs successfully, run your heartbeat:

node heartbeat.js

Check Node Status
You can monitor your node's status and activity on the official dashboard:

https://noem-heartbeat.replit.app/dashboard

Thank you for contributing to the NOEM network!