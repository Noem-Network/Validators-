
NOEM IPFS Node - Windows Installer
==================================

1. Extract this ZIP file to any folder.
2. Double-click 'install.bat' and follow the prompts.
3. IPFS will install, ask for your wallet address and amount of storage (in GB), then run the node + heartbeat agent.
4. A background script will run every 5 minutes to ping NOEM's network.

Dependencies:
Before you begin, ensure you have Node.js installed on your system. You can download it from https://nodejs.org/.

Configure your wallet and storage:
Before running the installation script, you must edit the config.json file.

Input your Bahamut EVM compatible wallet address. All rewards will be distributed to this address.

Specify the amount of storage you want to share.

Important Note: The wallet address configured in config.json will be used for all reward distributions. For now, this address cannot be changed after initial setup. Please ensure you use a wallet address that you will not lose or replace. Reward distribution will be based on your provided storage and the strike day node login activity.
