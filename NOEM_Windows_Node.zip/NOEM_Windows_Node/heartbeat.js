
const axios = require('axios');
const fs = require('fs');
const os = require('os');
const { execSync } = require('child_process');

const config = JSON.parse(fs.readFileSync('./config.json'));
const wallet = config.wallet;
const storage = config.storage;

async function sendHeartbeat() {
  try {
    await axios.post('https://noem-heartbeat.replit.app', {
      wallet,
      timestamp: new Date().toISOString(),
      storage
    });
    console.log(`✅ Sent heartbeat for ${wallet} with ${storage} GB`);
  } catch (err) {
    console.error("❌ Heartbeat failed:", err.message);
  }
}

sendHeartbeat();
setInterval(sendHeartbeat, 5 * 60 * 1000); // every 5 minutes
